﻿//using EBIBLIO.Data;
//using EBIBLIO.Models;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;

//namespace EBIBLIO.Controllers
//{
//    public class BookController : Controller
//    {
//        private readonly AppDbContext _context;

//        public BookController(AppDbContext context)
//        {
//            _context = context;
//        }

//        // Liste des livres
//        public async Task<IActionResult> Index()
//        {
//            var books = await _context.Books.Include(b => b.Category).ToListAsync();
//            return View(books);
//        }

//        // Formulaire de création (GET)
//        [HttpGet]
//        public IActionResult Create()
//        {
//            ViewBag.Categories = _context.Categories.ToList();
//            return View();
//        }

//        // Traitement de la création (POST)
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Create([Bind("Title,Author,AnneePub,CategoryId")] Book book)
//        {
//            if (ModelState.IsValid)
//            {
//                _context.Books.Add(book);
//                await _context.SaveChangesAsync();
//                return RedirectToAction(nameof(Index));
//            }

//            // Recharger les catégories en cas d'erreur de validation
//            ViewBag.Categories = await _context.Categories.ToListAsync();
//            return View(book);
//        }

//        // Mise à jour d'un livre (GET)
//        [HttpGet]
//        public async Task<IActionResult> Edit(int id)
//        {
//            var book = await _context.Books.FindAsync(id);
//            if (book == null)
//                return NotFound();

//            ViewBag.Categories = await _context.Categories.ToListAsync();
//            return View(book);
//        }

//        // Traitement de la mise à jour (POST)
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Author,AnneePub,CategoryId")] Book book)
//        {
//            if (id != book.Id)
//                return NotFound();

//            if (ModelState.IsValid)
//            {
//                try
//                {
//                    _context.Update(book);
//                    await _context.SaveChangesAsync();
//                    return RedirectToAction(nameof(Index));
//                }
//                catch (DbUpdateConcurrencyException)
//                {
//                    if (!BookExists(book.Id))
//                        return NotFound();

//                    ModelState.AddModelError("", "Une erreur de concurrence s'est produite.");
//                    return View(book);
//                }
//            }

//            ViewBag.Categories = await _context.Categories.ToListAsync();
//            return View(book);
//        }

//        private bool BookExists(int id)
//        {
//            return _context.Books.Any(e => e.Id == id);
//        }

//        // Affichage du formulaire de suppression (GET)
//        [HttpGet]
//        public async Task<IActionResult> Delete(int id)
//        {
//            var book = await _context.Books
//                .Include(b => b.Category)
//                .FirstOrDefaultAsync(m => m.Id == id);

//            if (book == null)
//                return NotFound();

//            return View(book);
//        }

//        // Traitement de la suppression (POST)
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> DeleteConfirmed(int id)
//        {
//            var book = await _context.Books.FindAsync(id);
//            if (book == null)
//                return NotFound();

//            //bool isBorrowed = await _context.Borrows.AnyAsync(b => b.BookId == id);
//            //if (isBorrowed)
//            //{
//            //    ModelState.AddModelError("", "Ce livre est actuellement emprunté et ne peut pas être supprimé.");
//            //    return View(book);
//            //}

//            _context.Books.Remove(book);
//            await _context.SaveChangesAsync();
//            return RedirectToAction(nameof(Index));
//        }
//    }
//}

using EBIBLIO.Data;
using EBIBLIO.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;

namespace EBIBLIO.Controllers
{
    [Authorize(Roles = "Admin")]
    public class BookController : Controller
    {
        private readonly AppDbContext _context;

        public BookController(AppDbContext context)
        {
            _context = context;
        }

        // Liste des livres
        public async Task<IActionResult> Index()
        {
            var books = await _context.Books.Include(b => b.Category).ToListAsync();
            return View(books);
        }

        // Formulaire de création (GET)
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Name");
            return View();
        }

        // Traitement de la création (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Title,Author,AnneePub,CategoryId")] Book book)
        {
            //if (ModelState.IsValid)
            //{
                _context.Books.Add(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            //}

            //ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Name", book.CategoryId);
            //return View(book);
        }

        // Formulaire de mise à jour (GET)
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
                return NotFound();

            ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Name", book.CategoryId);
            return View(book);
        }

        // Traitement de la mise à jour (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Author,AnneePub,CategoryId")] Book book)
        {
            if (id != book.Id)
                return NotFound();

            //if (ModelState.IsValid)
            //{
                try
                {
                    _context.Update(book);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.Id))
                        return NotFound();

                    ModelState.AddModelError("", "Une erreur de concurrence s'est produite.");
                }
            //}

            //ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Name", book.CategoryId);
            return View(book);
        }

        // Vérifie si un livre existe
        private bool BookExists(int id)
        {
            return _context.Books.Any(e => e.Id == id);
        }

        // Formulaire de suppression (GET)
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var book = await _context.Books
                .Include(b => b.Category)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (book == null)
                return NotFound();

            return View(book);
        }

        // Traitement de la suppression (POST)
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> DeleteConfirmed(int id)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)

        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
                return NotFound();

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}

