﻿//using EBIBLIO.Data;
//using EBIBLIO.Models;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.Extensions.Logging;

//namespace EBIBLIO.Controllers
//{
//    public class BorrowController : Controller
//    {
//        private readonly AppDbContext _context;
//        private readonly ILogger<BorrowController> _logger;

//        public BorrowController(AppDbContext context, ILogger<BorrowController> logger)
//        {
//            _context = context;
//            _logger = logger;
//        }

//        public async Task<IActionResult> Index()
//        {
//            var borrows = await _context.Borrows
//                .Include(b => b.Book)
//                .Include(b => b.User)
//                .ToListAsync();
//            return View(borrows);
//        }

//        [HttpGet]
//        public IActionResult Create()
//        {
//            var books = _context.Books.ToList();
//            var users = _context.Users.ToList();

//            if (!books.Any() || !users.Any())
//            {
//                ModelState.AddModelError("", "Aucun livre ou utilisateur disponible.");
//                return View();
//            }

//            // Vérification pour éviter NullReferenceException
//            ViewBag.Books = books.Any() ? new SelectList(books, "Id", "Title") : new SelectList(new List<Book>());
//            ViewBag.Users = users.Any() ? new SelectList(users, "Id", "UserName") : new SelectList(new List<User>());

//            return View();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Create([Bind("BookId, UserId")] Borrow borrow)
//        {
//            if (_context.Books.Find(borrow.BookId) == null || _context.Users.Find(borrow.UserId) == null)
//            {
//                ModelState.AddModelError("", "Livre ou utilisateur invalide.");
//                ViewBag.Books = new SelectList(_context.Books, "Id", "Title");
//                ViewBag.Users = new SelectList(_context.Users, "Id", "UserName");
//                return View(borrow);
//            }

//            borrow.DateBorrowed = DateTime.Now;
//            _context.Borrows.Add(borrow);
//            await _context.SaveChangesAsync();

//            return RedirectToAction(nameof(Index));
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Return(int id)
//        {
//            var borrow = await _context.Borrows
//                .Include(b => b.Book)
//                .Include(b => b.User)
//                .FirstOrDefaultAsync(b => b.Id == id);

//            if (borrow == null) return NotFound();

//            borrow.DateReturned = DateTime.Now;
//            borrow.IsReturned = true;
//            await _context.SaveChangesAsync();

//            return RedirectToAction(nameof(Index));
//        }
//    }

//    internal class User
//    {
//    }
//}

/////////////////////////////////////////////////////////
//using EBIBLIO.Data;
//using EBIBLIO.Models;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.AspNetCore.Authorization;

//namespace EBIBLIO.Controllers
//{
//    public class BorrowController : Controller
//    {
//        private readonly AppDbContext _context;

//        public BorrowController(AppDbContext context)
//        {
//            _context = context;
//        }

//        public async Task<IActionResult> Index()
//        {
//            var borrows = await _context.Borrows
//                .Include(b => b.Book)
//                .Include(b => b.User)
//                .ToListAsync();
//            return View(borrows);
//        }

//        [HttpGet]
//        public IActionResult Create()
//        {
//            var books = _context.Books.ToList();
//            var users = _context.Users.ToList();

//            if (!books.Any() || !users.Any())
//            {
//                ModelState.AddModelError("", "Aucun livre ou utilisateur disponible.");
//                return View();
//            }

//            ViewBag.Books = new SelectList(_context.Books.ToList(), "Id", "Title");
//            ViewBag.Users = new SelectList(_context.Users.ToList(), "Id", "UserName");

//            //ViewBag.Books = new SelectList(books, "Id", "Title");
//            //ViewBag.Users = new SelectList(users, "Id", "UserName");

//            return View();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Create([Bind("BookId, UserId")] Borrow borrow)
//        {
//            //if (ModelState.IsValid)
//            //{
//                borrow.DateBorrowed = DateTime.Now;
//                _context.Borrows.Add(borrow);
//                await _context.SaveChangesAsync();
//                return RedirectToAction(nameof(Index));
//            //}

//            //ViewBag.Books = new SelectList(_context.Books.ToList(), "Id", "Title");
//            //ViewBag.Users = new SelectList(_context.Users.ToList(), "Id", "UserName");
//            //return View(borrow);
//        }

//        // 🔹 Action GET : Affiche la page de confirmation
//        [HttpGet]
//        public async Task<IActionResult> Return(int id)
//        {
//            var borrow = await _context.Borrows
//                .Include(b => b.Book)
//                .Include(b => b.User)
//                .FirstOrDefaultAsync(b => b.Id == id);

//            if (borrow == null) return NotFound();

//            return View(borrow); // Renvoie la vue de confirmation
//        }

//        // 🔹 Action POST : Effectue le retour du livre
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> ConfirmReturn(int id)
//        {
//            var borrow = await _context.Borrows.FindAsync(id);
//            if (borrow == null) return NotFound();

//            borrow.DateReturned = DateTime.Now;
//            borrow.IsReturned = true;
//            await _context.SaveChangesAsync();

//            return RedirectToAction(nameof(Index));
//        }
//    }
//}

////////////////////////////////////////////////
//using EBIBLIO.Data;
//using EBIBLIO.Models;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.AspNetCore.Authorization;

//namespace EBIBLIO.Controllers
//{
//    public class BorrowController : Controller
//    {
//        private readonly AppDbContext _context;

//        public BorrowController(AppDbContext context)
//        {
//            _context = context;
//        }

//        public async Task<IActionResult> Index()
//        {
//            var borrows = await _context.Borrows
//                .Include(b => b.Book)
//                .Include(b => b.User)
//                .ToListAsync();
//            return View(borrows);
//        }

//        [HttpGet]
//        public IActionResult Create()
//        {
//            var books = _context.Books.ToList();
//            var users = _context.Users.ToList();

//            if (!books.Any() || !users.Any())
//            {
//                ModelState.AddModelError("", "Aucun livre ou utilisateur disponible.");
//                return View();
//            }

//            ViewBag.Books = new SelectList(books, "Id", "Title");
//            ViewBag.Users = new SelectList(users, "Id", "UserName");

//            return View();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Create([Bind("BookId, UserId")] Borrow borrow)
//        {
//            //    if (ModelState.IsValid)
//            //    {
//            borrow.DateBorrowed = DateTime.Now;
//            _context.Borrows.Add(borrow);
//            await _context.SaveChangesAsync();
//            return RedirectToAction(nameof(Index));
//            // }

//            //ViewBag.Books = new SelectList(_context.Books.ToList(), "Id", "Title");
//            //ViewBag.Users = new SelectList(_context.Users.ToList(), "Id", "UserName");
//            //return View(borrow);
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Return(int id)
//        {
//            var borrow = await _context.Borrows.FindAsync(id);
//            if (borrow == null) return NotFound();

//            borrow.DateReturned = DateTime.Now;
//            borrow.IsReturned = true;
//            await _context.SaveChangesAsync();

//            return RedirectToAction(nameof(Index));
//        }
//    }
//}

/////////////////////////////////////////////////////
//using EBIBLIO.Data;
//using EBIBLIO.Models;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.AspNetCore.Authorization;

//namespace EBIBLIO.Controllers
//{
//    public class BorrowController : Controller
//    {
//        private readonly AppDbContext _context;

//        public BorrowController(AppDbContext context)
//        {
//            _context = context;
//        }

//        public async Task<IActionResult> Index()
//        {
//            var borrows = await _context.Borrows
//                .Include(b => b.Book)
//                .Include(b => b.User)
//                .ToListAsync();
//            return View(borrows);
//        }

//        [HttpGet]
//        public IActionResult Create()
//        {
//            ViewBag.Books = _context.Books.ToList();
//            ViewBag.Users = _context.Users.ToList();
//            return View();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Create([Bind("BookId, UserId")] Borrow borrow)
//        {
//            if (ModelState.IsValid)
//            {
//                borrow.DateBorrowed = DateTime.Now;
//                _context.Borrows.Add(borrow); // Suppression du cast explicite inutile
//                await _context.SaveChangesAsync();
//                return RedirectToAction(nameof(Index));
//            }

//            ViewBag.Books = _context.Books.ToList();
//            ViewBag.Users = _context.Users.ToList();
//            return View(borrow);
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Return(int id)
//        {
//            var borrow = await _context.Borrows.FindAsync(id);
//            if (borrow == null) return NotFound();

//            borrow.DateReturned = DateTime.Now;
//            borrow.IsReturned = true;
//            await _context.SaveChangesAsync();

//            return RedirectToAction(nameof(Index));
//        }
//    }
//}


////////////////////////////////////////////////////////////////////////////////////////////////////

//using EBIBLIO.Data;
//using EBIBLIO.Models;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.AspNetCore.Authorization;
//namespace EBIBLIO.Controllers
//{
//    public class BorrowController : Controller
//    {
//        private readonly AppDbContext _context;

//        public BorrowController(AppDbContext context)
//        {
//            _context = context;
//        }

//        public async Task<IActionResult> Index()
//        {
//            var borrows = await _context.Borrows.Include(b => b.Book).Include(b => b.User).ToListAsync();
//            return View(borrows);
//        }

//        [HttpGet]
//        public IActionResult Create()
//        {
//            ViewBag.Books = _context.Books.ToList();
//            ViewBag.Users = _context.Users.ToList();
//            return View();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Create([Bind("BookId, UserId, DateEmprunt")] Borrow borrow)
//        {
//            //if (ModelState.IsValid)
//            //{
//            borrow.DateBorrowed = DateTime.Now;
//            _context.Borrows.Add(borrow); // Explicitly cast to Borrow  
//            await _context.SaveChangesAsync();
//            return RedirectToAction(nameof(Index));
//            //}

//            //ViewBag.Books = _context.Books.ToList();
//            //ViewBag.Users = _context.Users.ToList();
//            //ViewBag.Borrows = _context.Borrows.ToList();
//            //return View(borrow);
//        }

//        //[HttpPost]
//        //[ValidateAntiForgeryToken]
//        //public async Task<IActionResult> Return(int id)
//        //{
//        //    var borrow = await _context.Borrows.FindAsync(id);
//        //    if (borrow == null) return NotFound();

//        //    borrow.DateReturned = DateTime.Now;
//        //    await _context.SaveChangesAsync();

//        //    return RedirectToAction(nameof(Index));
//        //}


//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Return(int id)
//        {
//            var borrow = await _context.Borrows
//                .Include(b => b.Book)
//                .Include(b => b.User)
//                .FirstOrDefaultAsync(b => b.Id == id);

//            if (borrow == null) return NotFound();

//            borrow.DateReturned = DateTime.Now;
//            borrow.IsReturned = true;
//            await _context.SaveChangesAsync();

//            return RedirectToAction(nameof(Index));
//        }
//    }
//}

///////////////////////////////////////////////////////////////////////
///
using EBIBLIO.Data;
using EBIBLIO.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EBIBLIO.Controllers
{
    public class BorrowController : Controller
    {
        private readonly AppDbContext _context;

        public BorrowController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var borrows = await _context.Borrows
                .Include(b => b.Book)
                .Include(b => b.User)
                .ToListAsync();
            return View(borrows);
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Books = _context.Books.ToList();
            ViewBag.Users = _context.Users.ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookId, UserId, DateEmprunt")] Borrow borrow)
        {
            borrow.DateBorrowed = DateTime.Now;
            _context.Borrows.Add(borrow);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // 🔹 Affiche la page de confirmation (GET)
        [HttpGet]
        public async Task<IActionResult> Return(int id)
        {
            var borrow = await _context.Borrows
                .Include(b => b.Book)
                .Include(b => b.User)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (borrow == null)
                return NotFound();

            return View(borrow); // Affiche Return.cshtml
        }

        // 🔹 Confirme le retour (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Return(Borrow borrow)
        {
            var existingBorrow = await _context.Borrows.FindAsync(borrow.Id);
            if (existingBorrow == null)
                return NotFound();

            existingBorrow.DateReturned = DateTime.Now;
            existingBorrow.IsReturned = true;
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
