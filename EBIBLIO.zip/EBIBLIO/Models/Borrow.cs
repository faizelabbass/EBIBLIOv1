﻿namespace EBIBLIO.Models
{
    public class Borrow
    {
        public int Id { get; set; }
        public DateTime DateBorrowed { get; set; }
        public DateTime DateReturned { get; set; }
        public bool IsReturned { get; set; } = false;

        public int BookId { get; set; }
        public required Book Book { get; set; } // Assure que Book ne peut pas être null

        

        public required string UserId { get; set; } // Ajout de required pour éviter l'erreur
        public required Users User { get; set; } // Assure que User est toujours défini
    }
}
