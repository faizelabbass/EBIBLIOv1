﻿using Microsoft.AspNetCore.Identity;

namespace EBIBLIO.Models
{
    public class Users : IdentityUser
    {
        public string FullName { get; set; }
       
        public ICollection<Borrow> Borrows { get; set; } = new List<Borrow>();
    }
}
