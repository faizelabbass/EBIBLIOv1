﻿namespace EBIBLIO.Models
{
    public class Book
    {
        public int Id { get; set; }
        public required string Title { get; set; }
        public required string Author { get; set; }
        public DateTime AnneePub { get; set; }

        public int CategoryId { get; set; }
        public required Category Category { get; set; }
        public ICollection<Borrow> Borrows { get; set; } = new List<Borrow>();
    }
    //public class Book
    //{
    //    public int Id { get; set; }
    //    public string Title { get; set; } = string.Empty;
    //    public string Author { get; set; } = string.Empty;
    //    public DateTime AnneePub { get; set; }
    //    public int CategoryId { get; set; }
    //    public Category Category { get; set; } = new Category();
    //}
}
